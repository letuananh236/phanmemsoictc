import { storage, showToast } from './storage.js';

export function createCaptureView(appState) {
  let container;
  let videoEl;
  let galleryEl;
  let selectedEl;
  let currentStream;
  let capturedImages = [];
  let selectedImages = [];
  let captureContext = { examId: '' };
  let keyHandler;

  document.addEventListener('exam:context', (event) => {
    captureContext = event.detail;
  });

  const PREFERRED_CAMERA_KEY = 'preferredCameraId';

  async function listCameras(selectEl) {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoDevices = devices.filter((d) => d.kind === 'videoinput');
    selectEl.innerHTML = '';
    videoDevices.forEach((device) => {
      const option = document.createElement('option');
      option.value = device.deviceId;
      option.textContent = device.label || `Camera ${selectEl.length + 1}`;
      selectEl.appendChild(option);
    });

    const saved = localStorage.getItem(PREFERRED_CAMERA_KEY);
    if (saved && videoDevices.some((d) => d.deviceId === saved)) {
      selectEl.value = saved;
    }
  }

  async function startCamera(deviceId) {
    if (currentStream) {
      currentStream.getTracks().forEach((track) => track.stop());
    }
    currentStream = await navigator.mediaDevices.getUserMedia({
      video: deviceId ? { deviceId: { exact: deviceId } } : true,
      audio: false
    });
    if (deviceId) {
      localStorage.setItem(PREFERRED_CAMERA_KEY, deviceId);
    }
    videoEl.srcObject = currentStream;
    await videoEl.play();
  }

  function renderGallery() {
    galleryEl.innerHTML = '';
    capturedImages.forEach((image, index) => {
      const item = document.createElement('div');
      item.className = 'gallery-item';
      item.innerHTML = `
        <input type="checkbox" ${selectedImages.includes(image) ? 'checked' : ''} />
        <img src="${image.dataUrl}" alt="Ảnh ${index + 1}" />
        <span>${image.name}</span>
      `;
      const checkbox = item.querySelector('input');
      checkbox.addEventListener('change', () => toggleSelection(image));
      galleryEl.appendChild(item);
    });
    renderSelectedPreview();
  }

  function toggleSelection(image) {
    const limit = appState.settings?.defaultImageCount || 4;
    if (selectedImages.includes(image)) {
      selectedImages = selectedImages.filter((img) => img !== image);
    } else {
      if (selectedImages.length >= limit) {
        alert(`Chỉ được chọn tối đa ${limit} ảnh`);
        return;
      }
      selectedImages.push(image);
    }
    renderGallery();
  }

  function renderSelectedPreview() {
    selectedEl.innerHTML = '';
    const limit = appState.settings?.defaultImageCount || 4;
    for (let i = 0; i < limit; i += 1) {
      const image = selectedImages[i];
      const slot = document.createElement('div');
      slot.className = 'image-slot';
      if (image) {
        slot.innerHTML = `<img src="${image.dataUrl}" alt="Ảnh đã chọn" />`;
      } else {
        slot.textContent = 'Chưa chọn';
      }
      selectedEl.appendChild(slot);
    }
  }

  function capturePhoto() {
    if (!videoEl) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoEl.videoWidth;
    canvas.height = videoEl.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoEl, 0, 0);
    const dataUrl = canvas.toDataURL('image/png');
    const image = {
      name: `${captureContext.examId || 'HA'}_${capturedImages.length + 1}.png`,
      dataUrl
    };
    capturedImages.unshift(image);
    renderGallery();
  }

  async function acceptImages() {
    const examId = captureContext.examId || 'HA000000';
    const uploads = [];
    for (let i = 0; i < selectedImages.length; i += 1) {
      const image = selectedImages[i];
      const uploadResult = await storage.uploadImage(examId, i + 1, image.dataUrl);
      uploads.push({ path: uploadResult.path, dataUrl: image.dataUrl });
    }
    document.dispatchEvent(new CustomEvent('images:selected', { detail: uploads }));
    showToast('Đã gửi ảnh sang phiếu khám');
  }

  function clearImages() {
    capturedImages = [];
    selectedImages = [];
    renderGallery();
  }

  return {
    render(target) {
      container = document.createElement('section');
      container.className = 'card capture-view';
      container.innerHTML = `
          <div class="capture-layout">
          <div class="capture-controls">
            <div class="form-row">
              <label>Chọn camera</label>
              <select id="camera-select"></select>
              <small class="hint">Lưu tự động camera mặc định sau khi mở.</small>
            </div>
            <div class="form-row split">
              <button type="button" id="start-camera">Mở camera</button>
              <button type="button" id="capture-photo">Chụp hình</button>
            </div>
            <div class="form-row">
              <h4>Ảnh đã chọn</h4>
              <div class="image-grid selected-grid" id="selected-images"></div>
            </div>
            <div class="form-row">
              <button type="button" id="accept-images">Chấp nhận (F10)</button>
              <button type="button" class="secondary" id="clear-images">Xóa tất cả</button>
            </div>
          </div>
          <div class="capture-preview">
            <video autoplay playsinline muted class="video"></video>
          </div>
          <div class="capture-gallery">
            <h4>Gallery ảnh</h4>
            <div id="capture-gallery"></div>
          </div>
        </div>
      `;
      target.appendChild(container);

      videoEl = container.querySelector('video');
      galleryEl = container.querySelector('#capture-gallery');
      selectedEl = container.querySelector('#selected-images');

      const selectEl = container.querySelector('#camera-select');
      listCameras(selectEl).then(() => {
        const saved = localStorage.getItem(PREFERRED_CAMERA_KEY);
        if (saved) {
          startCamera(saved).catch(() => {
            showToast('Không thể mở camera đã lưu, hãy chọn lại');
          });
        }
      });

      container.querySelector('#start-camera').addEventListener('click', () => startCamera(selectEl.value));
      container.querySelector('#capture-photo').addEventListener('click', capturePhoto);
      container.querySelector('#accept-images').addEventListener('click', acceptImages);
      container.querySelector('#clear-images').addEventListener('click', clearImages);
      selectedImages = appState.selectedImages || [];
      renderSelectedPreview();

      if (keyHandler) {
        window.removeEventListener('keydown', keyHandler);
      }
      keyHandler = (event) => {
        if (event.key === 'F10' && container.isConnected) {
          event.preventDefault();
          acceptImages();
        }
      };
      window.addEventListener('keydown', keyHandler);
    }
  };
}
